const http = require('http');

http.createServer(function(req,res){
    res.writeHead(200,{'Content-type':'text/html'});
    res.write("<h1>Wellcom to Node.js wed Server. To chaaliyeee suru karte haiiii......</h1>");
    res.end();

}).listen(3000);

console.log("Server running at http://localhost:3000"); 


