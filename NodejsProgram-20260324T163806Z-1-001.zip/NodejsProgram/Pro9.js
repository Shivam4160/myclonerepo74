
const http = require('http');
const os = require('os');
http.createServer(function (req, res) {
    res.write("Hostname: " + os.hostname() + "\n");
    res.write("Platform: " + os.platform() + "\n");
    res.write("Free Memory: " + os.freemem());
    res.end();
}).listen(3000);
console.log("Server running at http://localhost:3000");

