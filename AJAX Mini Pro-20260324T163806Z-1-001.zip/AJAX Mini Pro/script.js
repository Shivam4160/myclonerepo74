function getStudent() {
    var sid = document.getElementById("sid").value;

    //Create XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    //
    xhr.open("GET","student.json", true);

xhr.onreadystatechange = function() {
    if(xhr.readyState == 4 && xhr.status == 200){
        var data = JSON.parse(xhr.responseText);

        var students = data.students;

        var output = "Student NOT found";

        for (var i = 0; i < students.length; i++) {
            if(students[i].id == sid){
                output = `
                    Name: ${students[i].name} <br>
                    Course: ${students[i].course} <br>
                    Marks: ${students[i].mark}
                `
            }
        }
        document.getElementById("result").innerHTML = output ;
    }
};

xhr.send();

}
